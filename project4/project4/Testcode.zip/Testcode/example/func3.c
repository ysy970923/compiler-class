void print(int a){
	write_int(a);
}

int main(){
	int a;
	a = 10;

	print(a);
	write_string("\n");
}
