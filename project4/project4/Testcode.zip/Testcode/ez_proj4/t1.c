int y;

int *x;

int main(){
y=*x;
}
