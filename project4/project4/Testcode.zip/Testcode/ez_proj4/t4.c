
int main(){

int y;

int x;

x = 3;

y=x++;

}
