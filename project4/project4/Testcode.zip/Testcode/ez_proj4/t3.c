int y;

int x;

int main(){

x = 3;

y=x++;

}
